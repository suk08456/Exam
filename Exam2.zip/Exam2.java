public class Exam2 {
    public static void main(String[] args) {
        // 높이를 입력해주세요 : 3                // 출력

        for(int i = 1; i <= 1; i++){
            System.out.println(" *");
            for(int j = 1; j <= 3; j++)
            System.out.print("*");
            for(int t = 1; t <= 5; t++){
                System.out.print("*");
            }
        }
        /*

         *

         ***

         *****

         */

        // 높이를 입력해주세요 : 5

        // 출력

        /*

         *

         ***

         *****

         *******

         *********

         */

        // 높이를 입력해주세요 : 7

        // 출력

        /*

         *

         ***

         *****

         *******

         *********

         ***********

         *************

         */

    }

}
